# Copyright (c) Facebook, Inc. and its affiliates. All Rights Reserved.
import torch
import torch.nn.functional as F
from torch import nn


class FPN(nn.Module):
    """
    Module that adds FPN on top of a list of feature maps.
    The feature maps are currently supposed to be in increasing depth
    order, and must be consecutive
    """

    def __init__(
        self, in_channels_list, out_channels, conv_block, top_blocks=None
    ):
        """
        Arguments:
            in_channels_list (list[int]): number of channels for each feature map that
                will be fed
            out_channels (int): number of channels of the FPN representation
            top_blocks (nn.Module or None): if provided, an extra operation will
                be performed on the output of the last (smallest resolution)
                FPN output, and the result will extend the result list
        """
        super(FPN, self).__init__()
        self.inner_blocks = []
        self.layer_blocks = []
        for idx, in_channels in enumerate(in_channels_list, 1):
            inner_block = "fpn_inner{}".format(idx)
            layer_block = "fpn_layer{}".format(idx)
            #print('idx:',idx, 'inner_block:', inner_block, 'layer_block: ',layer_block)
            '''                          # in -> out
            idx: 1 fpn_inner1 fpn_layer1 # 0  -> 128
            idx: 2 fpn_inner2 fpn_layer2 # 32 -> 128
            idx: 3 fpn_inner3 fpn_layer3 # 96 -> 128
            idx: 4 fpn_inner4 fpn_layer4 # 320-> 128
            '''
            if in_channels == 0:
                continue
            inner_block_module = conv_block(in_channels, out_channels, 1)
            layer_block_module = conv_block(out_channels, out_channels, 3, 1)
            self.add_module(inner_block, inner_block_module)
            self.add_module(layer_block, layer_block_module)
            self.inner_blocks.append(inner_block)
            self.layer_blocks.append(layer_block)


        self.top_blocks = top_blocks
    def forward(self, x):
        """
        Arguments:
            x (list[Tensor]): feature maps for each feature level.
        Returns:
            results (tuple[Tensor]): feature maps after FPN layers.
                They are ordered from highest resolution first.
        """
        #print('last_inner.shape: ', last_inner.shape)
        #print('self.inner_blocks.shape: ',self.inner_blocks[-1])
        #print('x.shape: ',x[-1].shape)
        #if len(x[-1].shape)==3:
        #    x[-1]=torch.unsqueeze(x[-1],0)
        #print('x.shape after: ',x[-1].shape)
        #if len(x[-1].shape)==3:
        #    print('x.shape before : ',len(x[-1].shape))
        #    last_inner = getattr(self, self.inner_blocks[-1])(torch.unsqueeze(x[-1],0))
        #    print('x.shape after: ',torch.unsqueeze(x[-1],0).shape)
        #else:

        last_inner = getattr(self, self.inner_blocks[-1])(x[-1])

        #print('last_inner.shape: ', last_inner.shape)                   #[1, 128, 22, 29]
        results = []
        results.append(getattr(self, self.layer_blocks[-1])(last_inner))
        #print('self.inner_blocks: ',self.inner_blocks) #  ['fpn_inner2', 'fpn_inner3', 'fpn_inner4']
        #print('self.layer_blocks',self.layer_blocks)   #  ['fpn_inner2', 'fpn_inner3', 'fpn_inner4']
        #print('x[:-1][::-1]:', x[:-1][::-1])
        #print('self.inner_blocks[:-1][::-1]:',self.inner_blocks[:-1][::-1])
        #print('self.layer_blocks[:-1][::-1]:',self.layer_blocks[:-1][::-1])
        for feature, inner_block, layer_block in zip(
                x[:-1][::-1], self.inner_blocks[:-1][::-1], self.layer_blocks[:-1][::-1]
        ):
            if not inner_block:
                continue
            inner_top_down = F.interpolate(last_inner, scale_factor=2, mode="nearest")
            inner_lateral = getattr(self, inner_block)(feature)
            # TODO use size instead of scale to make it robust to different sizes
            # inner_top_down = F.upsample(last_inner, size=inner_lateral.shape[-2:],
            # mode='bilinear', align_corners=False)
            last_inner = inner_lateral + inner_top_down
            #print('inner_top_down.shape:',inner_top_down.shape) #: torch.Size([1, 128, 64, 42])  torch.Size([1, 128, 128, 84])
            #print('inner_lateral.shape:',inner_lateral.shape)   #: torch.Size([1, 128, 64, 42])  torch.Size([1, 128, 128, 84])
            #print('last_inner.shape:',last_inner.shape)         #: torch.Size([1, 128, 64, 42])  torch.Size([1, 128, 128, 84])
            results.insert(0, getattr(self, layer_block)(last_inner))

        if isinstance(self.top_blocks, LastLevelP6P7):
            last_results = self.top_blocks(x[-1], results[-1])
            results.extend(last_results)
        elif isinstance(self.top_blocks, LastLevelMaxPool):
            last_results = self.top_blocks(results[-1])
            results.extend(last_results)

        return tuple(results)

    def forward2(self, x):
        """
        Arguments:
            x (list[Tensor]): feature maps for each feature level.
        Returns:
            results (tuple[Tensor]): feature maps after FPN layers.
                They are ordered from highest resolution first.
        """
        last_inner = getattr(self, self.inner_blocks[-1])(x[-1])
        results = []
        results.append(getattr(self, self.layer_blocks[-1])(last_inner))
        for feature, inner_block, layer_block in zip(
            x[:-1][::-1], self.inner_blocks[:-1][::-1], self.layer_blocks[:-1][::-1]
        ):
            if not inner_block:
                continue
            inner_top_down = F.interpolate(last_inner, scale_factor=2, mode="nearest")
            inner_lateral = getattr(self, inner_block)(feature)
            # TODO use size instead of scale to make it robust to different sizes
            # inner_top_down = F.upsample(last_inner, size=inner_lateral.shape[-2:],
            # mode='bilinear', align_corners=False)
            last_inner = inner_lateral + inner_top_down
            #print('inner_top_down.shape:',inner_top_down.shape) #: torch.Size([1, 128, 64, 42])  torch.Size([1, 128, 128, 84])
            #print('inner_lateral.shape:',inner_lateral.shape)   #: torch.Size([1, 128, 64, 42])  torch.Size([1, 128, 128, 84])
            #print('last_inner.shape:',last_inner.shape)         #: torch.Size([1, 128, 64, 42])  torch.Size([1, 128, 128, 84])
            results.insert(0, getattr(self, layer_block)(last_inner))

        if isinstance(self.top_blocks, LastLevelP6P7):
            last_results = self.top_blocks(x[-1], results[-1])
            results.extend(last_results)
        elif isinstance(self.top_blocks, LastLevelMaxPool):
            last_results = self.top_blocks(results[-1])
            results.extend(last_results)

        return tuple(results)


class LastLevelMaxPool(nn.Module):
    def forward(self, x):
        return [F.max_pool2d(x, 1, 2, 0)]


class LastLevelP6P7(nn.Module):
    """
    This module is used in RetinaNet to generate extra layers, P6 and P7.
    """
    def __init__(self, in_channels, out_channels):
        super(LastLevelP6P7, self).__init__()
        #print('LastLevelP6P7: ',in_channels, out_channels)#128 128
        self.p6 = nn.Conv2d(in_channels, out_channels, 3, 2, 1)
        self.p7 = nn.Conv2d(out_channels, out_channels, 3, 2, 1)
        for module in [self.p6, self.p7]:
            nn.init.kaiming_uniform_(module.weight, a=1)
            nn.init.constant_(module.bias, 0)
        self.use_P5 = in_channels == out_channels

    def forward(self, c5, p5):
        x = p5 if self.use_P5 else c5
        p6 = self.p6(x)
        p7 = self.p7(F.relu(p6))
        #print('p6.shape:',p6.shape)#p6.shape: torch.Size([1, 128, 16, 11])
        #print('p7.shape:',p7.shape)#p7.shape: torch.Size([1, 128, 8, 6])
        return [p6, p7]
